package com.graziela.mensalidadeescolar


import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Conectando os componentes do XML
        val edtIdade = findViewById<EditText>(R.id.edtIdade)
        val edtMensalidade = findViewById<EditText>(R.id.edtMensalidade)
        val btnCalcular = findViewById<Button>(R.id.btnCalcular)
        val txtResultado = findViewById<TextView>(R.id.txtResultado)

        // Ação do botão
        btnCalcular.setOnClickListener {

            val idadeTexto = edtIdade.text.toString().trim()
            val valorTexto = edtMensalidade.text.toString().trim()

            // Validando campos vazios
            if (idadeTexto.isEmpty()) {
                edtIdade.error = "Digite a idade"
                return@setOnClickListener
            }

            if (valorTexto.isEmpty()) {
                edtMensalidade.error = "Digite a mensalidade"
                return@setOnClickListener
            }

            val idade = idadeTexto.toIntOrNull()
            val mensalidade = valorTexto
                .replace(",", ".").toDoubleOrNull()

            if (idade == null || idade < 10) {
                edtIdade.error = "Idade mínima: 10 anos"
                return@setOnClickListener
            }

            if (mensalidade == null || mensalidade <= 0) {
                edtMensalidade.error = "Digite um valor válido"
                return@setOnClickListener
            }

            // Definindo o percentual
            val percentual = when {
                idade == 10 -> 4.0
                idade in 11..17 -> 6.0
                else -> 8.0
            }

            // Calculando o reajuste
            val reajuste = mensalidade * percentual / 100
            val novoValor = mensalidade + reajuste

            // Identificando a faixa etária
            val faixa = when {
                idade == 10 -> "10 anos"
                idade in 11..17 -> "11 a 17 anos"
                else -> "Acima de 17 anos"
            }

            // Formatando valores em reais
            val formato = NumberFormat.getCurrencyInstance(
                Locale("pt", "BR")
            )

            // Apresentando o resultado
            txtResultado.text = """
                RESULTADO DO CÁLCULO

                Faixa etária: $faixa
                Reajuste aplicado: ${percentual.toInt()}%
                Valor do reajuste: ${formato.format(reajuste)}

                NOVA MENSALIDADE:
                ${formato.format(novoValor)}
            """.trimIndent()
        }
    }
}
